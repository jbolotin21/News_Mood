

```python
# Dependencies and Twitter API Keys and Authorizations
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import json
import tweepy
from datetime import datetime
from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer
analyzer = SentimentIntensityAnalyzer()
from config import (consumer_key, 
                    consumer_secret, 
                    access_token, 
                    access_token_secret)
auth = tweepy.OAuthHandler(consumer_key, consumer_secret)
auth.set_access_token(access_token, access_token_secret)
api = tweepy.API(auth, parser=tweepy.parsers.JSONParser())
```


```python
# Create array of news twitter handles BBC, CBS, CNN, Fox, and New York times 
newsOutlets = ["BBCNews", "CBSNews","CNN", "FoxNews", "nytimes"]
```


```python
# Print a tweet
test_tweet = api.user_timeline(newsOutlets[0])
print(json.dumps(test_tweet[0], sort_keys=True, indent=4))
```

    {
        "contributors": null,
        "coordinates": null,
        "created_at": "Wed Jun 06 00:40:24 +0000 2018",
        "entities": {
            "hashtags": [],
            "symbols": [],
            "urls": [
                {
                    "display_url": "bbc.in/2HmKrwd",
                    "expanded_url": "https://bbc.in/2HmKrwd",
                    "indices": [
                        59,
                        82
                    ],
                    "url": "https://t.co/DVihP4PE2z"
                }
            ],
            "user_mentions": []
        },
        "favorite_count": 1,
        "favorited": false,
        "geo": null,
        "id": 1004161047173959680,
        "id_str": "1004161047173959680",
        "in_reply_to_screen_name": null,
        "in_reply_to_status_id": null,
        "in_reply_to_status_id_str": null,
        "in_reply_to_user_id": null,
        "in_reply_to_user_id_str": null,
        "is_quote_status": false,
        "lang": "en",
        "place": null,
        "possibly_sensitive": false,
        "retweet_count": 0,
        "retweeted": false,
        "source": "<a href=\"http://www.socialflow.com\" rel=\"nofollow\">SocialFlow</a>",
        "text": "Take a look inside the world's largest legal cannabis farm https://t.co/DVihP4PE2z",
        "truncated": false,
        "user": {
            "contributors_enabled": false,
            "created_at": "Mon Jan 08 08:05:57 +0000 2007",
            "default_profile": false,
            "default_profile_image": false,
            "description": "News, features and analysis. For world news, follow @BBCWorld. Breaking news, follow @BBCBreaking. Latest sport news @BBCSport. Our Instagram: BBCNews",
            "entities": {
                "description": {
                    "urls": []
                },
                "url": {
                    "urls": [
                        {
                            "display_url": "bbc.co.uk/news",
                            "expanded_url": "http://www.bbc.co.uk/news",
                            "indices": [
                                0,
                                23
                            ],
                            "url": "https://t.co/vBzl7LNCCQ"
                        }
                    ]
                }
            },
            "favourites_count": 36,
            "follow_request_sent": false,
            "followers_count": 9458312,
            "following": false,
            "friends_count": 99,
            "geo_enabled": true,
            "has_extended_profile": false,
            "id": 612473,
            "id_str": "612473",
            "is_translation_enabled": true,
            "is_translator": false,
            "lang": "en",
            "listed_count": 39673,
            "location": "London",
            "name": "BBC News (UK)",
            "notifications": false,
            "profile_background_color": "FFFFFF",
            "profile_background_image_url": "http://abs.twimg.com/images/themes/theme1/bg.png",
            "profile_background_image_url_https": "https://abs.twimg.com/images/themes/theme1/bg.png",
            "profile_background_tile": false,
            "profile_banner_url": "https://pbs.twimg.com/profile_banners/612473/1467627928",
            "profile_image_url": "http://pbs.twimg.com/profile_images/875702547016802304/9TC6qsAT_normal.jpg",
            "profile_image_url_https": "https://pbs.twimg.com/profile_images/875702547016802304/9TC6qsAT_normal.jpg",
            "profile_link_color": "1F527B",
            "profile_sidebar_border_color": "FFFFFF",
            "profile_sidebar_fill_color": "FFFFFF",
            "profile_text_color": "5A5A5A",
            "profile_use_background_image": true,
            "protected": false,
            "screen_name": "BBCNews",
            "statuses_count": 354611,
            "time_zone": null,
            "translator_type": "regular",
            "url": "https://t.co/vBzl7LNCCQ",
            "utc_offset": null,
            "verified": true
        }
    }
    


```python
# Create array for sentiments
sentiment_array = []
```


```python
# Loop through all five media outlets
for outlet in newsOutlets:
    counter = 1   
    
    # For each outlet loop through 5 pages of tweets (total 100 tweets)
    for x in range(5):

        # Get user's tweets, specifying the page
        public_tweets = api.user_timeline(outlet, page=x)

        # Loop through all tweets
        for tweet in public_tweets:
            
            #Get info for each tweet 
                      
            # Get account handle and full user name
            tweet_target = tweet["user"]["screen_name"]
            tweet_name = tweet["user"]["name"]
            
            # Convert tweet date
            converted_time = datetime.strptime(tweet["created_at"], "%a %b %d %H:%M:%S %z %Y")
            
            # Get tweet text
            tweet_text = tweet["text"]
            
            # Run sentiment analysis
            results = analyzer.polarity_scores(tweet["text"])
            pos = results["pos"]
            neg = results["neg"]
            neu = results["neu"]
            comp = results["compound"]
            
            # Place data in a dictionary
            sentiment = {"TweetsAgo":counter,
                         "Target": tweet_target,
                         "User": tweet_name,
                         "Date": converted_time,
                         "Text": tweet_text,
                         "Compound": comp,
                         "Positive": pos,
                         "Neutral": neu,
                         "Negative": neg
                        }
            
            # Append dictionary to master sentiment array
            sentiment_array.append(sentiment)

        # Increment counter
            counter +=1
```


```python
# Make sure there are 100 tweets for each outlet (500 total)
len(sentiment_array)
```




    500




```python
# Create sentiments data frame
sentiments_df = pd.DataFrame(sentiment_array)
```


```python
sentiments_df = sentiments_df[["TweetsAgo","Target","User","Date","Positive","Neutral","Negative","Compound","Text"]]
sentiments_df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>TweetsAgo</th>
      <th>Target</th>
      <th>User</th>
      <th>Date</th>
      <th>Positive</th>
      <th>Neutral</th>
      <th>Negative</th>
      <th>Compound</th>
      <th>Text</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>BBCNews</td>
      <td>BBC News (UK)</td>
      <td>2018-06-06 00:40:24+00:00</td>
      <td>0.143</td>
      <td>0.857</td>
      <td>0.000</td>
      <td>0.1280</td>
      <td>Take a look inside the world's largest legal c...</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2</td>
      <td>BBCNews</td>
      <td>BBC News (UK)</td>
      <td>2018-06-06 00:38:04+00:00</td>
      <td>0.190</td>
      <td>0.810</td>
      <td>0.000</td>
      <td>0.2755</td>
      <td>Scotland and Britain 'cannot be mistaken for e...</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3</td>
      <td>BBCNews</td>
      <td>BBC News (UK)</td>
      <td>2018-06-06 00:38:04+00:00</td>
      <td>0.000</td>
      <td>0.645</td>
      <td>0.355</td>
      <td>-0.6597</td>
      <td>'How a TV show led to my cancer diagnosis' htt...</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4</td>
      <td>BBCNews</td>
      <td>BBC News (UK)</td>
      <td>2018-06-06 00:38:04+00:00</td>
      <td>0.000</td>
      <td>0.818</td>
      <td>0.182</td>
      <td>-0.2500</td>
      <td>Reality Check: Is a driver shortage messing up...</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5</td>
      <td>BBCNews</td>
      <td>BBC News (UK)</td>
      <td>2018-06-06 00:38:02+00:00</td>
      <td>0.000</td>
      <td>0.845</td>
      <td>0.155</td>
      <td>-0.2960</td>
      <td>Why beige carbs are the ones to avoid - Dr Xan...</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Sort data frame by target and tweets ago
sentiments_df = sentiments_df.sort_values(["Target","TweetsAgo"], ascending=[True, False])
sentiments_df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>TweetsAgo</th>
      <th>Target</th>
      <th>User</th>
      <th>Date</th>
      <th>Positive</th>
      <th>Neutral</th>
      <th>Negative</th>
      <th>Compound</th>
      <th>Text</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>99</th>
      <td>100</td>
      <td>BBCNews</td>
      <td>BBC News (UK)</td>
      <td>2018-06-05 11:50:49+00:00</td>
      <td>0.202</td>
      <td>0.743</td>
      <td>0.055</td>
      <td>0.5780</td>
      <td>RT @bbclaurak: And least surprising story of t...</td>
    </tr>
    <tr>
      <th>98</th>
      <td>99</td>
      <td>BBCNews</td>
      <td>BBC News (UK)</td>
      <td>2018-06-05 11:57:55+00:00</td>
      <td>0.188</td>
      <td>0.812</td>
      <td>0.000</td>
      <td>0.4019</td>
      <td>"This is a project with benefits that reach fa...</td>
    </tr>
    <tr>
      <th>97</th>
      <td>98</td>
      <td>BBCNews</td>
      <td>BBC News (UK)</td>
      <td>2018-06-05 12:01:35+00:00</td>
      <td>0.000</td>
      <td>1.000</td>
      <td>0.000</td>
      <td>0.0000</td>
      <td>Loris Karius: Liverpool keeper referred for co...</td>
    </tr>
    <tr>
      <th>96</th>
      <td>97</td>
      <td>BBCNews</td>
      <td>BBC News (UK)</td>
      <td>2018-06-05 12:22:27+00:00</td>
      <td>0.000</td>
      <td>1.000</td>
      <td>0.000</td>
      <td>0.0000</td>
      <td>Syphilis and gonorrhoea cases up by one-fifth ...</td>
    </tr>
    <tr>
      <th>95</th>
      <td>96</td>
      <td>BBCNews</td>
      <td>BBC News (UK)</td>
      <td>2018-06-05 12:24:46+00:00</td>
      <td>0.000</td>
      <td>1.000</td>
      <td>0.000</td>
      <td>0.0000</td>
      <td>Tesco Bank hit by online glitch https://t.co/0...</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Save twitter data to CSV file
sentiments_df.to_csv("recentTweets.csv", encoding="utf-8", index=False)
```


```python
# Create charting data frames for each type
BBC_df = sentiments_df[sentiments_df["Target"]=="BBCNews"]
CBS_df = sentiments_df[sentiments_df["Target"]=="CBSNews"]
CNN_df = sentiments_df[sentiments_df["Target"]=="CNN"]
FOX_df = sentiments_df[sentiments_df["Target"]=="FoxNews"]
NYT_df = sentiments_df[sentiments_df["Target"]=="nytimes"]
```


```python
# Plot the News Outlets
# BBC
plt.scatter(BBC_df["TweetsAgo"], BBC_df["Compound"], marker="o", facecolors="turquoise", edgecolors="black", label="BBCWorld", alpha=0.75)

# CBS
plt.scatter(CBS_df["TweetsAgo"], CBS_df["Compound"], marker="o", facecolors="green", edgecolors="black", label="CBSNews", alpha=0.75)

# CNN
plt.scatter(CNN_df["TweetsAgo"], CNN_df["Compound"], marker="o", facecolors="red", edgecolors="black", label="CNN", alpha=0.75)

# Fox
plt.scatter(FOX_df["TweetsAgo"], FOX_df["Compound"], marker="o", facecolors="blue", edgecolors="black", label="FoxNews", alpha=0.75)

# New York Times
plt.scatter(NYT_df["TweetsAgo"], NYT_df["Compound"], marker="o", facecolors="gold", edgecolors="black", label="NYTimes", alpha=0.75)
```




    <matplotlib.collections.PathCollection at 0x201d20323c8>




![png](output_11_1.png)



```python
# Plot the News Outlets from above
plt.scatter(BBC_df["TweetsAgo"], BBC_df["Compound"], marker="o", facecolors="turquoise", edgecolors="black", label="BBC", alpha=1)
plt.scatter(CBS_df["TweetsAgo"], CBS_df["Compound"], marker="o", facecolors="green", edgecolors="black", label="CBS", alpha=1)
plt.scatter(CNN_df["TweetsAgo"], CNN_df["Compound"], marker="o", facecolors="red", edgecolors="black", label="CNN", alpha=1)
plt.scatter(FOX_df["TweetsAgo"], FOX_df["Compound"], marker="o", facecolors="blue", edgecolors="black", label="Fox", alpha=1)
plt.scatter(NYT_df["TweetsAgo"], NYT_df["Compound"], marker="o", facecolors="gold", edgecolors="black", label="New York Times", alpha=1)

# Set current date
curDate = datetime.now().date()

# Add labels and style
plt.title(f"Sentiment Analysis of Media Tweets ({curDate})", fontsize=15)
plt.xlabel("Tweets Ago", fontsize=12)
plt.ylabel("Tweet Polarity", fontsize=12)
plt.style.use('seaborn')
plt.grid(linestyle='-', linewidth='0.5', color='white')

# Set the x and y limits
plt.xlim(105, -5)
plt.ylim(-1, 1)

# Add the legend
lgnd= plt.legend(bbox_to_anchor=(1.32, 1.013), frameon = False, facecolor = 'white', loc="upper right", scatterpoints=1, fontsize=12, title="Media Sources")
plt.savefig('sentiment_analysis.png')
plt.show()
```


![png](output_12_0.png)



```python
# Group the data by media outlet
groupedNews = sentiments_df.groupby(["User"], as_index=False)
groupedNews.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>TweetsAgo</th>
      <th>Target</th>
      <th>User</th>
      <th>Date</th>
      <th>Positive</th>
      <th>Neutral</th>
      <th>Negative</th>
      <th>Compound</th>
      <th>Text</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>99</th>
      <td>100</td>
      <td>BBCNews</td>
      <td>BBC News (UK)</td>
      <td>2018-06-05 11:50:49+00:00</td>
      <td>0.202</td>
      <td>0.743</td>
      <td>0.055</td>
      <td>0.5780</td>
      <td>RT @bbclaurak: And least surprising story of t...</td>
    </tr>
    <tr>
      <th>98</th>
      <td>99</td>
      <td>BBCNews</td>
      <td>BBC News (UK)</td>
      <td>2018-06-05 11:57:55+00:00</td>
      <td>0.188</td>
      <td>0.812</td>
      <td>0.000</td>
      <td>0.4019</td>
      <td>"This is a project with benefits that reach fa...</td>
    </tr>
    <tr>
      <th>97</th>
      <td>98</td>
      <td>BBCNews</td>
      <td>BBC News (UK)</td>
      <td>2018-06-05 12:01:35+00:00</td>
      <td>0.000</td>
      <td>1.000</td>
      <td>0.000</td>
      <td>0.0000</td>
      <td>Loris Karius: Liverpool keeper referred for co...</td>
    </tr>
    <tr>
      <th>96</th>
      <td>97</td>
      <td>BBCNews</td>
      <td>BBC News (UK)</td>
      <td>2018-06-05 12:22:27+00:00</td>
      <td>0.000</td>
      <td>1.000</td>
      <td>0.000</td>
      <td>0.0000</td>
      <td>Syphilis and gonorrhoea cases up by one-fifth ...</td>
    </tr>
    <tr>
      <th>95</th>
      <td>96</td>
      <td>BBCNews</td>
      <td>BBC News (UK)</td>
      <td>2018-06-05 12:24:46+00:00</td>
      <td>0.000</td>
      <td>1.000</td>
      <td>0.000</td>
      <td>0.0000</td>
      <td>Tesco Bank hit by online glitch https://t.co/0...</td>
    </tr>
    <tr>
      <th>199</th>
      <td>100</td>
      <td>CBSNews</td>
      <td>CBS News</td>
      <td>2018-06-05 12:25:24+00:00</td>
      <td>0.000</td>
      <td>1.000</td>
      <td>0.000</td>
      <td>0.0000</td>
      <td>“I just started thinking about this last night...</td>
    </tr>
    <tr>
      <th>198</th>
      <td>99</td>
      <td>CBSNews</td>
      <td>CBS News</td>
      <td>2018-06-05 12:27:27+00:00</td>
      <td>0.000</td>
      <td>1.000</td>
      <td>0.000</td>
      <td>0.0000</td>
      <td>“The first time i started having conversations...</td>
    </tr>
    <tr>
      <th>197</th>
      <td>98</td>
      <td>CBSNews</td>
      <td>CBS News</td>
      <td>2018-06-05 12:30:35+00:00</td>
      <td>0.000</td>
      <td>1.000</td>
      <td>0.000</td>
      <td>0.0000</td>
      <td>AHEAD on @CBSThisMorning: @Oprah will reveal h...</td>
    </tr>
    <tr>
      <th>196</th>
      <td>97</td>
      <td>CBSNews</td>
      <td>CBS News</td>
      <td>2018-06-05 12:32:08+00:00</td>
      <td>0.000</td>
      <td>1.000</td>
      <td>0.000</td>
      <td>0.0000</td>
      <td>RT @CBSThisMorning: .@Oprah recalls sitting in...</td>
    </tr>
    <tr>
      <th>195</th>
      <td>96</td>
      <td>CBSNews</td>
      <td>CBS News</td>
      <td>2018-06-05 12:33:27+00:00</td>
      <td>0.000</td>
      <td>1.000</td>
      <td>0.000</td>
      <td>0.0000</td>
      <td>Here’s a look at some of this morning’s headli...</td>
    </tr>
    <tr>
      <th>299</th>
      <td>100</td>
      <td>CNN</td>
      <td>CNN</td>
      <td>2018-06-05 14:32:38+00:00</td>
      <td>0.000</td>
      <td>0.868</td>
      <td>0.132</td>
      <td>-0.4404</td>
      <td>Fox News is facing criticism after it aired ph...</td>
    </tr>
    <tr>
      <th>298</th>
      <td>99</td>
      <td>CNN</td>
      <td>CNN</td>
      <td>2018-06-05 14:42:52+00:00</td>
      <td>0.000</td>
      <td>0.637</td>
      <td>0.363</td>
      <td>-0.6908</td>
      <td>Apple's not the only company worried about you...</td>
    </tr>
    <tr>
      <th>297</th>
      <td>98</td>
      <td>CNN</td>
      <td>CNN</td>
      <td>2018-06-05 14:54:00+00:00</td>
      <td>0.000</td>
      <td>0.805</td>
      <td>0.195</td>
      <td>-0.5574</td>
      <td>RT @CNNnewsroom: "Make no mistake about it, it...</td>
    </tr>
    <tr>
      <th>296</th>
      <td>97</td>
      <td>CNN</td>
      <td>CNN</td>
      <td>2018-06-05 15:01:00+00:00</td>
      <td>0.061</td>
      <td>0.939</td>
      <td>0.000</td>
      <td>0.0772</td>
      <td>Six months after they helped Democrat Doug Jon...</td>
    </tr>
    <tr>
      <th>295</th>
      <td>96</td>
      <td>CNN</td>
      <td>CNN</td>
      <td>2018-06-05 15:10:05+00:00</td>
      <td>0.000</td>
      <td>0.839</td>
      <td>0.161</td>
      <td>-0.3612</td>
      <td>Student loan debt just hit $1.5 trillion. Wome...</td>
    </tr>
    <tr>
      <th>399</th>
      <td>100</td>
      <td>FoxNews</td>
      <td>Fox News</td>
      <td>2018-06-05 16:16:42+00:00</td>
      <td>0.000</td>
      <td>0.719</td>
      <td>0.281</td>
      <td>-0.6486</td>
      <td>JUST IN: Fashion designer Kate Spade found dea...</td>
    </tr>
    <tr>
      <th>398</th>
      <td>99</td>
      <td>FoxNews</td>
      <td>Fox News</td>
      <td>2018-06-05 16:30:19+00:00</td>
      <td>0.149</td>
      <td>0.649</td>
      <td>0.201</td>
      <td>-0.2023</td>
      <td>Months after Pence promise, Iraqi Christians s...</td>
    </tr>
    <tr>
      <th>397</th>
      <td>98</td>
      <td>FoxNews</td>
      <td>Fox News</td>
      <td>2018-06-05 16:31:55+00:00</td>
      <td>0.000</td>
      <td>1.000</td>
      <td>0.000</td>
      <td>0.0000</td>
      <td>Kentucky high school valedictorian trolls crow...</td>
    </tr>
    <tr>
      <th>396</th>
      <td>97</td>
      <td>FoxNews</td>
      <td>Fox News</td>
      <td>2018-06-05 16:37:51+00:00</td>
      <td>0.000</td>
      <td>1.000</td>
      <td>0.000</td>
      <td>0.0000</td>
      <td>Pizza chain offering pizza bouquets, boutonnie...</td>
    </tr>
    <tr>
      <th>395</th>
      <td>96</td>
      <td>FoxNews</td>
      <td>Fox News</td>
      <td>2018-06-05 16:46:14+00:00</td>
      <td>0.000</td>
      <td>0.820</td>
      <td>0.180</td>
      <td>-0.2960</td>
      <td>Deputy takes down hammer-wielding suspect with...</td>
    </tr>
    <tr>
      <th>499</th>
      <td>100</td>
      <td>nytimes</td>
      <td>The New York Times</td>
      <td>2018-06-05 10:00:08+00:00</td>
      <td>0.000</td>
      <td>1.000</td>
      <td>0.000</td>
      <td>0.0000</td>
      <td>Morning Briefing: Here's what you need to know...</td>
    </tr>
    <tr>
      <th>498</th>
      <td>99</td>
      <td>nytimes</td>
      <td>The New York Times</td>
      <td>2018-06-05 10:14:04+00:00</td>
      <td>0.340</td>
      <td>0.660</td>
      <td>0.000</td>
      <td>0.8020</td>
      <td>President Trump abruptly called off the White ...</td>
    </tr>
    <tr>
      <th>497</th>
      <td>98</td>
      <td>nytimes</td>
      <td>The New York Times</td>
      <td>2018-06-05 10:31:08+00:00</td>
      <td>0.000</td>
      <td>1.000</td>
      <td>0.000</td>
      <td>0.0000</td>
      <td>"It is not part of the job description of an a...</td>
    </tr>
    <tr>
      <th>496</th>
      <td>97</td>
      <td>nytimes</td>
      <td>The New York Times</td>
      <td>2018-06-05 10:45:05+00:00</td>
      <td>0.000</td>
      <td>0.817</td>
      <td>0.183</td>
      <td>-0.6908</td>
      <td>Harvey Weinstein is scheduled to be back in co...</td>
    </tr>
    <tr>
      <th>495</th>
      <td>96</td>
      <td>nytimes</td>
      <td>The New York Times</td>
      <td>2018-06-05 11:00:07+00:00</td>
      <td>0.097</td>
      <td>0.756</td>
      <td>0.147</td>
      <td>-0.2960</td>
      <td>President Trump declared in a tweet on Monday ...</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Get avg compound sentiment
avgcomp = groupedNews['Compound'].mean()
avgcomp.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>User</th>
      <th>Compound</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>BBC News (UK)</td>
      <td>-0.000300</td>
    </tr>
    <tr>
      <th>1</th>
      <td>CBS News</td>
      <td>0.009738</td>
    </tr>
    <tr>
      <th>2</th>
      <td>CNN</td>
      <td>-0.010702</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Fox News</td>
      <td>0.024205</td>
    </tr>
    <tr>
      <th>4</th>
      <td>The New York Times</td>
      <td>-0.043081</td>
    </tr>
  </tbody>
</table>
</div>




```python
news_teams = avgcomp['User']
news_comp = avgcomp['Compound']
x_axis = np.arange(0,len(news_comp), 1)
```


```python
news_comp
```




    0   -0.000300
    1    0.009738
    2   -0.010702
    3    0.024205
    4   -0.043081
    Name: Compound, dtype: float64




```python
# group by SN and find average of each group
scores_by_org = avgcomp.groupby('User')['Compound'].mean()
scores_by_org

# Create barchart
plt.bar(x_axis, news_comp, color=["turquoise", "green", "red", "blue", "gold"], align = "edge")
tick_location = [value+.4 for value in x_axis]
plt.xticks(tick_location, news_teams)

# Set limits
plt.xlim(-.5, len(x_axis))
plt.ylim(-.05, .03)

# Titles and labels
plt.title(f"Overall Media Sentiment based on Twitter {curDate}")
plt.xlabel("Media Sources")
plt.ylabel("Tweet Polarity")

count = 0 # for x coord location of value label
# Create each value label
for score in scores_by_org: 
    if score < 0: #for neg scores, put label under
        height = score - .005
    else: # for + scores, put label above
        height = score + .004
    plt.text(count, height, str(round(score, 2)), multialignment = 'right', va = 'center')
    count += 1
```


![png](output_17_0.png)



```python
# Save png
plt.savefig('overall_media.png')
plt.show()
```


    <Figure size 576x396 with 0 Axes>

